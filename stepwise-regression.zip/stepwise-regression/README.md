# stepwise-regression
Stepwise regression fits a logistic regression model in which the choice of predictive variables is carried out by an automatic stepwise procedure.
